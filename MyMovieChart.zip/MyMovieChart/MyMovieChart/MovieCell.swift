//
//  MovieCell.swift
//  MyMovieChart
//
//  Created by LEE on 2020/11/13.
//

import UIKit
class MovieCell: UITableViewCell {
    @IBOutlet weak var title: UILabel! // 영화제목
    @IBOutlet weak var desc: UILabel! // 영화설명
    @IBOutlet weak var opendate: UILabel! // 개봉일
    @IBOutlet weak var rating: UILabel! // 평점
    @IBOutlet weak var thumnail: UIImageView!
    
}
