//
//  TheaterCell.swift
//  MyMovieChart
//
//  Created by LEE on 2020/11/13.
//

import UIKit
class TheaterCell: UITableViewCell{
    
    
    @IBOutlet var name: UILabel!
    
    @IBOutlet var tel: UILabel!
    
    @IBOutlet var addr: UILabel!
}
