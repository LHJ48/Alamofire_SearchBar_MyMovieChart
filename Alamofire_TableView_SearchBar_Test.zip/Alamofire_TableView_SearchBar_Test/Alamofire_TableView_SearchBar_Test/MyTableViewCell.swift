//
//  MyTableViewCell.swift
//  Alamofire_TableView_SearchBar_Test
//
//  Created by LEE on 2020/11/02.
//

import UIKit

class MyTableViewCell: UITableViewCell {

    @IBOutlet weak var lbName: UILabel!
    @IBOutlet weak var lbHeight: UILabel!
    @IBOutlet weak var lbWeight: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
