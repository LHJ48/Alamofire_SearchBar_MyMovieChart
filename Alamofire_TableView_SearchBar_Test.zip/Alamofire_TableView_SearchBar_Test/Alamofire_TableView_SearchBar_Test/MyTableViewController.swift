//
//  MyTableViewController.swift
//  Alamofire_TableView_SearchBar_Test
//
//  Created by LEE on 2020/11/02.
//

import UIKit
import SwiftyJSON
import Alamofire

class MyTableViewController: UITableViewController,UISearchBarDelegate{
    

    
    @IBOutlet weak var MysearchBar: UISearchBar!
    @IBOutlet var Mytableview: UITableView!
    
    var filteredData : [String]!
    var filteredData1 : [String]!
    var filteredData2 : [String]!
    var location_name_array = [String]()
    var location_height_array = [String]()
    var location_weight_array = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sendRequset()
        
        Mytableview.rowHeight = 120
        Mytableview.separatorColor = UIColor.black
        Mytableview.cellLayoutMarginsFollowReadableWidth = false
        Mytableview.separatorInset.left = 0
        
        filteredData = location_name_array
        filteredData1 = location_height_array
        filteredData2 = location_weight_array
        
        self.MysearchBar.delegate = self
        self.MysearchBar.placeholder = "Search Name"
        
        self.Mytableview.delegate = self
        self.Mytableview.dataSource = self
        

    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return filteredData.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyTableVIewCell", for: indexPath) as! MyTableViewCell
        
        let row = indexPath.row
        
        cell.lbName.text = filteredData[row]
        cell.lbHeight.text = filteredData1[row]
        cell.lbWeight.text = filteredData2[row]
        
        return cell
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        filteredData = searchText.isEmpty ? location_name_array : location_name_array.filter({(dataString:String)->Bool in
            return dataString.range(of: searchText, options: .caseInsensitive) != nil
        })
        
        Mytableview.reloadData()
    }
    
    func sendRequset(){
        //POST방식
        let parameter : Parameters = [
            "user_id" : "hong",
            "user_pw" : "1234"
        ]
        
        let url :String = "http://nissisoft21.dothome.co.kr/login_test.php"
        
        Alamofire.request(url,
                          method: .post,
                          parameters: parameter,
                          encoding: URLEncoding.httpBody,
                          headers: [ "Content-Type" : "application/x-www.form=urlencoded",                                                    "Accept" : "application/json"]
        ).validate(statusCode: 200..<300)
        .responseJSON(completionHandler: {
            (response) in
            print(response)
            
            self.parseJSON(response)
        })
    }
    
    func parseJSON(_ response: DataResponse<Any>){
        switch response.result {
        case .success(_):
            if let json = try? JSON(data: response.data!){
                let result = json["login_result"]["result"].string
                print(result!)
                
                let message = json["login_result"]["message"].string
                print(message!)
                
                let login_return = json["login_result"]["login_data"]["return"].string
                print(login_return!)
                
                let login_message = json["login_result"]["login_data"]["message"].string
                print(login_message!)
                
                // 배열
                let arrayData = json["login_result"]["list"].array

                for data in arrayData!{
                    let name = data["name"].string
                    print(name!)
                    let height = data["height"].string
                    print(height!)
                    let weight = data["weight"].string
                    print(weight!)
                    self.location_name_array.append(name!)
                    self.location_height_array.append(height!)
                    self.location_weight_array.append(weight!)
                }
                
                DispatchQueue.main.async {
                    self.filteredData = self.location_name_array
                    self.filteredData1 = self.location_height_array
                    self.filteredData2 = self.location_weight_array
                    
                    self.Mytableview.reloadData()
                    
                    self.refreshControl?.endRefreshing()
                }
                
                
            }
            break
        case .failure(_):
            print("통신을 실패함.",String(describing: response.error))
            break
        }
        
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = false
        searchBar.text = ""
        searchBar.resignFirstResponder()
    }

    @IBAction func refresh(_ sender: UIRefreshControl) {
        sender.endRefreshing()
        Mytableview.reloadData()
    }
}
